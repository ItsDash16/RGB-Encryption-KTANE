# KTaNE-Module-Template

A template for creating modded modules for Keep Talking and Nobody Explodes. Access it as a plugin from the community version of the KTaNE ModKit!

More info at the [wiki](https://github.com/TheKuroEver/KTaNE-Module-Template/wiki)!
